// SurveyManger
// ========================================
// Invokes Poll Daddy surveys based on ratio
// records ratio result in a client cookie
//
// Constructor arguments
// -------------------------
// aSurveyID: 		String Id of survey assigned by PollDaddy
// aRatio:			Floating point number representing hit ratio. 0.1 = 10% or 1 in 10
// cookieDomain:	Domain in which cookie will be stored
// persistResults:	Set to true to persist statistcal results for current survey 

var SurveyManger = $.klass({

	// Constructor
	initialize: function(aSurveyId,aRatio,cookieDomain, persistResults) 
	{

		this.surveyId = aSurveyId;
		this.ratio = aRatio; 
		this.domain = cookieDomain;
		this.setCookie = persistResults
		
		this.jar = new $.cookieJar('quicklinks',{  
			expires:630720000,   // seconds   
			domain: this.domain,
			path: '/'  
		});  

	},
	
	// Call to perform statictical check and launch survey if in range.
	// Should be called on page load.  
	launchSurvey: function()
	{
		if (this.surveyId != this.jar.get('lastSurveyId'))
		{
			randomNum = Math.random();
			if (randomNum <= this.ratio)
			{
				PDF_launch(this.surveyId);
			} 
		}
		
		if (this.setCookie)
		{
			this.jar.set('lastSurveyId', this.surveyId);
		}
		
	},
	
	clearLastId: function()
	{
		this.jar.put('lastSurveyId', "");
	},
	
	persistResults: function(aBoolean)
	{
		this.setCookie = aBoolean;
	}
		
});

// Page specific initalization

var surveyMgr = null;

function initSurveyManager(rememberResults)
{
	
	
	// PDF_surveyID is set by PollDaddy provided JS code. 
	surveyMgr = new SurveyManger(PDF_surveyID,0.1,'engineering.ucf.dev', rememberResults);
}